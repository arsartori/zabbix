-- Dynamically build SQL Server template for Zabbix
-- Steinar Andersen , SQL Service 2013
-- Contact me at steinar.andersen@sqlservice or via www.sqlservice.se
-- Instructions:
-- Run it on the server you want to monitor
-- Set RESULTS TO GRID
-- Copy and paste all the resultsets to one file in notepad, save as Template_MicrosoftSQLServer_Multi_Database.xml
-- Import into Zabbix and add the host the file was generated on

set nocount on
declare @zabbix varchar(max)

-- Add the header part

select @zabbix = '<?xml version="1.0" encoding="UTF-8"?><zabbix_export><version>2.0</version><date>2013-05-26T14:16:10Z</date><groups><group><name>Templates</name></group></groups><templates><template><template>Template_MicrosoftSQLServer_Multi_Database</template><name>Template_MicrosoftSQLServer_Multi_Database</name><groups><group><name>Templates</name></group></groups><applications/><items>'
            
            
-- Add the static items

select @zabbix = @zabbix + '<item><name>SQL Default Instance: % Processor Time</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\Process(sqlservr)\% Processor Time&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Blocked Processes</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:General Statistics\Processes blocked&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>3</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Database Pages</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Buffer Manager\Database pages&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Data File Size</name><type>0</type><snmp_community/><multiplier>1</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Databases(_Total)\Data File(s) Size (KB)&quot;]</key><delay>300</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units>b</units><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1024</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Lock Waits per second</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Locks(_Total)\Lock Waits/sec&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Log File Size</name><type>0</type><snmp_community/><multiplier>1</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Databases(_Total)\Log File(s) Size (KB)&quot;]</key><delay>300</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units>b</units><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1024</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Longest Running Transaction</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Transactions\Longest Transaction Running Time&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>3</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description>The running time of the longest running transaction, in seconds</description><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Number Failed Jobs</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLAgent:Jobs(_Total)\Failed jobs&quot;]</key><delay>3600</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Number of Deadlocks per second</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Locks(_Total)\Number of Deadlocks/sec&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Number Users Connected</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:General Statistics\User Connections&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Page Life Expectancy</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Buffer Manager\Page Life Expectancy&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>3</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description>Low if under 300 for a some time</description><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Service State - Analysis Services</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>service_state[MSSQLServerOLAPService]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>3</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap><name>Windows service state</name></valuemap></item><item><name>SQL Default Instance: Service State - Integration Services</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>service_state[MSDtsServer]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>3</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap><name>Windows service state</name></valuemap></item><item><name>SQL Default Instance: Service State - Reporting Services</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>service_state[ReportServer]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>3</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap><name>Windows service state</name></valuemap></item><item><name>SQL Default Instance: Service State - SQL Agent</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>service_state[SQLServerAgent]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>3</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap><name>Windows service state</name></valuemap></item><item><name>SQL Default Instance: Service State - SQL Server</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>service_state[MSSQLSERVER]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>3</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap><name>Windows service state</name></valuemap></item><item><name>SQL Default Instance: Total Server Memory</name><type>0</type><snmp_community/><multiplier>1</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Memory Manager\Total Server Memory (KB)&quot;]</key><delay>300</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units>b</units><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1024</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item><item><name>SQL Default Instance: Transactions per second</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Databases(_Total)\Transactions/sec&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item>'


-- Add the dynamic items
-- Transactions per second for each database
 
 declare @dbname varchar(100)
DECLARE perf_cursor CURSOR
    FOR SELECT name from sys.databases 
OPEN perf_cursor
FETCH NEXT FROM perf_cursor into @dbname


WHILE @@FETCH_STATUS = 0

begin
select @zabbix = @zabbix + '<item><name>SQL Default Instance: Transactions/sec for DB '

select @zabbix = @zabbix + @dbname

select @zabbix = @zabbix + '</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Databases('
                    
select @zabbix = @zabbix + @dbname
 
 select @zabbix = @zabbix + ')\Transactions/sec&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item>'
FETCH NEXT FROM perf_cursor into @dbname
end

Close  perf_cursor
deallocate perf_cursor 


-- Fix for too many chars for ssms
select @zabbix
select @zabbix = ''
--End fix

-- Datafile size for each database
 

DECLARE perf_cursor CURSOR
    FOR SELECT name from sys.databases 
OPEN perf_cursor
FETCH NEXT FROM perf_cursor into @dbname


WHILE @@FETCH_STATUS = 0

begin
select @zabbix = @zabbix + '<item><name>SQL Default Instance: Datafile Size in KB for DB '

select @zabbix = @zabbix + @dbname

select @zabbix = @zabbix + '</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Databases('
                    
select @zabbix = @zabbix + @dbname
 
 select @zabbix = @zabbix + ')\Data File(s) Size (KB)&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item>'
FETCH NEXT FROM perf_cursor into @dbname
end

Close  perf_cursor
deallocate perf_cursor 

-- Fix for too many chars for ssms
select @zabbix
select @zabbix = ''
--End fix

-- Logfile size for each database
 

DECLARE perf_cursor CURSOR
    FOR SELECT name from sys.databases 
OPEN perf_cursor
FETCH NEXT FROM perf_cursor into @dbname


WHILE @@FETCH_STATUS = 0

begin
select @zabbix = @zabbix + '<item><name>SQL Default Instance: Logfile Size in KB for DB '

select @zabbix = @zabbix + @dbname

select @zabbix = @zabbix + '</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Databases('
                    
select @zabbix = @zabbix + @dbname
 
 select @zabbix = @zabbix + ')\Log File(s) Size (KB)&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item>'
FETCH NEXT FROM perf_cursor into @dbname
end

Close  perf_cursor
deallocate perf_cursor 
-- Fix for too many chars for ssms
select @zabbix
select @zabbix = ''
--End fix

-- Logfile size used for each database
 

DECLARE perf_cursor CURSOR
    FOR SELECT name from sys.databases 
OPEN perf_cursor
FETCH NEXT FROM perf_cursor into @dbname


WHILE @@FETCH_STATUS = 0

begin
select @zabbix = @zabbix + '<item><name>SQL Default Instance: Logfile in use in KB for DB '

select @zabbix = @zabbix + @dbname

select @zabbix = @zabbix + '</name><type>0</type><snmp_community/><multiplier>0</multiplier><snmp_oid/><key>perf_counter[&quot;\SQLServer:Databases('
                    
select @zabbix = @zabbix + @dbname
 
 select @zabbix = @zabbix + ')\Log File(s) Used Size (KB)&quot;]</key><delay>60</delay><history>7</history><trends>365</trends><status>0</status><value_type>0</value_type><allowed_hosts/><units/><delta>0</delta><snmpv3_securityname/><snmpv3_securitylevel>0</snmpv3_securitylevel><snmpv3_authpassphrase/><snmpv3_privpassphrase/><formula>1</formula><delay_flex/><params/><ipmi_sensor/><data_type>0</data_type><authtype>0</authtype><username/><password/><publickey/><privatekey/><port/><description/><inventory_link>0</inventory_link><applications/><valuemap/></item>'
FETCH NEXT FROM perf_cursor into @dbname
end

Close  perf_cursor
deallocate perf_cursor 
-- Fix for too many chars for ssms
select @zabbix
select @zabbix = ''
--End fix

-- End of items

 select @zabbix = @zabbix + '</items><discovery_rules/><macros/><templates/><screens/></template></templates>'

-- Add the static triggers
 select @zabbix = @zabbix +
'<triggers><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:perf_counter[&quot;\SQLServer:Transactions\Longest Transaction Running Time&quot;].last(0)}&gt;3600</expression><name>SQL Default Instance: Long running transaction: {ITEM.VALUE} seconds</name><url/><status>0</status><priority>2</priority><description>Too many blocked processes i SQL Server, more than 10 over a 10 minutes period</description><type>0</type><dependencies/></trigger><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:perf_counter[&quot;\SQLServer:General Statistics\Processes blocked&quot;].last(600)}&gt;10</expression><name>SQL Default Instance: Many Blocked Processes: {ITEM.VALUE}</name><url/><status>0</status><priority>2</priority><description>Too many blocked processes i SQL Server, more than 10 over a 10 minutes period</description><type>0</type><dependencies/></trigger><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:perf_counter[&quot;\SQLAgent:Jobs(_Total)\Failed jobs&quot;].change(0)}&gt;0</expression><name>SQL Default Instance: Number Failed Jobs</name><url/><status>0</status><priority>4</priority><description>Steinar testar 2</description><type>0</type><dependencies/></trigger><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:perf_counter[&quot;\SQLServer:Locks(_Total)\Number of Deadlocks/sec&quot;].last(0)}&gt;0</expression><name>SQL Default Instance: Number of Deadlocks per second</name><url/><status>0</status><priority>3</priority><description/><type>0</type><dependencies/></trigger><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:perf_counter[&quot;\SQLServer:Buffer Manager\Page Life Expectancy&quot;].last(300)}&lt;300</expression><name>SQL Default Instance: Page Life Expectancy low: {ITEM.VALUE}</name><url/><status>0</status><priority>3</priority><description>Memory pressure in SQL Server</description><type>0</type><dependencies/></trigger><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:service_state[MSSQLServerOLAPService].last(0)}&gt;0&amp;{Template_MicrosoftSQLServer_Multi_Database:service_state[MSSQLServerOLAPService].last(0)}&lt;255</expression><name>SQL Default Instance: Service State - Analysis Services</name><url/><status>0</status><priority>4</priority><description/><type>0</type><dependencies/></trigger><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:service_state[MSDtsServer].last(0)}&gt;0&amp;{Template_MicrosoftSQLServer_Multi_Database:service_state[MSDtsServer].last(0)}&lt;255</expression><name>SQL Default Instance: Service State - Integration Services</name><url/><status>0</status><priority>4</priority><description/><type>0</type><dependencies/></trigger><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:service_state[ReportServer].last(0)}&gt;0&amp;{Template_MicrosoftSQLServer_Multi_Database:service_state[ReportServer].last(0)}&lt;255</expression><name>SQL Default Instance: Service State - Reporting Services</name><url/><status>0</status><priority>4</priority><description/><type>0</type><dependencies/></trigger><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:service_state[SQLServerAgent].last(0)}&gt;0&amp;{Template_MicrosoftSQLServer_Multi_Database:service_state[SQLServerAgent].last(0)}&lt;255</expression><name>SQL Default Instance: Service State - SQL Agent</name><url/><status>0</status><priority>4</priority><description/><type>0</type><dependencies/></trigger><trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:service_state[MSSQLSERVER].last(0)}&gt;0&amp;{Template_MicrosoftSQLServer_Multi_Database:service_state[MSSQLSERVER].last(0)}&lt;255</expression><name>SQL Default Instance: Service State - SQL Server</name><url/><status>0</status><priority>4</priority><description/><type>0</type><dependencies/></trigger>'


-- Add the dynamic triggers
 
            
-- Trigger for Logfile used equals Log File Size (Soon to generate log file growth)
DECLARE perf_cursor CURSOR
    FOR SELECT name from sys.databases 
OPEN perf_cursor
FETCH NEXT FROM perf_cursor into @dbname


WHILE @@FETCH_STATUS = 0

begin
 select @zabbix = @zabbix + '<trigger><expression>{Template_MicrosoftSQLServer_Multi_Database:perf_counter[&quot;\SQLServer:Databases('
                    
select @zabbix = @zabbix + @dbname
 
 select @zabbix = @zabbix + ')\Log File(s) Used Size (KB)&quot;].last(0)}={Template_MicrosoftSQLServer_Multi_Database:perf_counter[&quot;\SQLServer:Databases('
 
 
 select @zabbix = @zabbix + @dbname
 
 select @zabbix = @zabbix + ')\Log File(s) Size (KB)&quot;].last(0)}</expression><name>SQL Default Instance: Log File usage = Log file Size in DB '
 
  select @zabbix = @zabbix + @dbname
 
 select @zabbix = @zabbix + '</name><url/><status>0</status><priority>2</priority><description>Too many blocked processes i SQL Server, more than 10 over a 10 minutes period</description><type>0</type><dependencies/></trigger>'



FETCH NEXT FROM perf_cursor into @dbname
end

Close  perf_cursor
deallocate perf_cursor 
-- Fix for too many chars for ssms
select @zabbix
select @zabbix = ''
--End fix
            
 
-- Add the footer part 
 select @zabbix = @zabbix + '
        </triggers></zabbix_export>'


-- Present the results
select @zabbix 